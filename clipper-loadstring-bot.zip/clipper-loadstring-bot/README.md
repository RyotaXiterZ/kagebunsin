# Clipper Loadstring Bot

Discord bot untuk menyimpan URL raw script yang kamu kelola di Supabase, lalu membuat snippet loader. Bot tidak mengunduh, menjalankan, atau memeriksa isi script. Gunakan hanya script milik sendiri atau yang kamu punya izin untuk distribusikan.

## Commands
- `/help` — bantuan.
- `/scripts` — Member/Admin melihat daftar script.
- `/loadstring name:<nama>` — Member/Admin membuat loader dari script tersimpan.
- `/addscript name:<nama> url:<https-url>` — Admin menambah script.
- `/deletescript name:<nama>` — Admin menghapus script.

## 1. Buat bot Discord
1. Buka https://discord.com/developers/applications lalu **New Application**.
2. Buka tab **Bot**, buat/reset token, lalu simpan rahasia.
3. Buka **OAuth2 > URL Generator**. Pilih scopes `bot` dan `applications.commands`.
4. Pilih permission minimum `Send Messages` dan `Embed Links`, lalu gunakan URL untuk mengundang bot.
5. Aktifkan Developer Mode di Discord, lalu salin Application ID, Server ID, dan ID role Admin serta Member.
6. Tidak perlu mengaktifkan Message Content Intent; bot hanya memakai slash commands.

## 2. Siapkan Supabase
1. Buat project di https://supabase.com/.
2. Buka **SQL Editor**, jalankan seluruh isi `schema.sql`.
3. Buka **Project Settings > API**, salin Project URL dan `service_role` key.
4. `service_role` adalah rahasia server. Jangan masukkan ke frontend/browser atau repository publik.

## 3. Environment variables
Salin `.env.example` menjadi `.env` dan isi seluruh nilainya. Untuk hosting, masukkan nilainya lewat menu Environment/Variables, bukan mengunggah `.env`.

## 4. Deploy tanpa Termux
Bot gateway Discord dengan discord.js membutuhkan proses Node.js yang terus berjalan. Gunakan layanan yang mendukung background worker/always-on service, misalnya Render Background Worker atau Railway.
1. Upload project ini ke repository GitHub. Pastikan `.env` tidak ikut diunggah.
2. Buat Background Worker/service Node.js dari repository.
3. Install/build command: `npm install`.
4. Start command: `npm start`.
5. Tambahkan semua variabel dari `.env.example` melalui dashboard hosting.
6. Daftarkan slash commands sekali dengan menjalankan `npm run deploy-commands` pada environment yang memiliki variabel tersebut. Bisa melalui shell hosting atau komputer yang sudah memasang Node.js.
7. Deploy/start worker. Log harus menampilkan `Logged in as ...`.

Pilih paket hosting yang mendukung worker aktif terus-menerus. Paket gratis tertentu dapat sleep atau membatasi proses background. Cloudflare Pages bukan tempat yang sesuai untuk discord.js Gateway bot.

## Struktur
```text
clipper-loadstring-bot/
├── src/config.js
├── src/commands.js
├── src/deploy-commands.js
├── src/index.js
├── .env.example
├── .gitignore
├── Dockerfile
├── package.json
├── README.md
└── schema.sql
```

## Keamanan
- Jangan bagikan Discord token atau Supabase service-role key.
- Jika token bocor, reset segera di dashboard masing-masing.
- Pastikan role Admin hanya diberikan ke orang tepercaya.
- URL disimpan sebagai HTTPS, tetapi bot tidak memverifikasi isi/reputasi URL.
- Bot hanya membuat teks loader; bot tidak mengeksekusi kode.
