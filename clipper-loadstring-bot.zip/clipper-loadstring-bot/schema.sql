-- Run in Supabase Dashboard -> SQL Editor.
create table if not exists public.scripts (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  url text not null,
  created_by text not null,
  created_at timestamptz not null default now()
);

alter table public.scripts enable row level security;
-- The bot accesses this table server-side with the service_role key.
-- Never expose that key in browser code or public repositories.
