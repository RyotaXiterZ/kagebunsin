const { REST, Routes } = require('discord.js');
const config = require('./config');
const { commands } = require('./commands');

async function main() {
  const rest = new REST({ version: '10' }).setToken(config.token);
  await rest.put(Routes.applicationGuildCommands(config.clientId, config.guildId), { body: commands });
  console.log(`Registered ${commands.length} slash commands in guild ${config.guildId}.`);
}

main().catch(error => {
  console.error('Command registration failed:', error);
  process.exit(1);
});
