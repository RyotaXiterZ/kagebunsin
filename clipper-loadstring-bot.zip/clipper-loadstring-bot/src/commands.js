const { SlashCommandBuilder } = require('discord.js');

const commands = [
  new SlashCommandBuilder()
    .setName('loadstring')
    .setDescription('Generate a loader for a saved script you are authorized to use.')
    .addStringOption(o => o.setName('name').setDescription('Saved script name').setRequired(true).setMaxLength(60)),
  new SlashCommandBuilder().setName('scripts').setDescription('Show saved script names.'),
  new SlashCommandBuilder()
    .setName('addscript').setDescription('Admin: save a script URL.')
    .addStringOption(o => o.setName('name').setDescription('Script name').setRequired(true).setMaxLength(60))
    .addStringOption(o => o.setName('url').setDescription('HTTPS raw script URL').setRequired(true).setMaxLength(500)),
  new SlashCommandBuilder()
    .setName('deletescript').setDescription('Admin: delete a saved script.')
    .addStringOption(o => o.setName('name').setDescription('Saved script name').setRequired(true).setMaxLength(60)),
  new SlashCommandBuilder().setName('help').setDescription('Show bot commands.')
].map(command => command.toJSON());

module.exports = { commands };
