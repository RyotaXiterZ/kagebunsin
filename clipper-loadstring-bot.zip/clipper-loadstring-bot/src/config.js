require('dotenv').config();

const required = [
  'DISCORD_TOKEN', 'DISCORD_CLIENT_ID', 'DISCORD_GUILD_ID',
  'ADMIN_ROLE_ID', 'MEMBER_ROLE_ID', 'SUPABASE_URL', 'SUPABASE_SERVICE_ROLE_KEY'
];
const missing = required.filter((key) => !process.env[key]);
if (missing.length) {
  console.error(`Missing environment variables: ${missing.join(', ')}`);
  process.exit(1);
}

module.exports = {
  token: process.env.DISCORD_TOKEN,
  clientId: process.env.DISCORD_CLIENT_ID,
  guildId: process.env.DISCORD_GUILD_ID,
  adminRoleId: process.env.ADMIN_ROLE_ID,
  memberRoleId: process.env.MEMBER_ROLE_ID,
  supabaseUrl: process.env.SUPABASE_URL,
  supabaseServiceRoleKey: process.env.SUPABASE_SERVICE_ROLE_KEY,
  ephemeral: process.env.EPHEMERAL_REPLIES !== 'false'
};
