const { Client, GatewayIntentBits, EmbedBuilder } = require('discord.js');
const { createClient } = require('@supabase/supabase-js');
const config = require('./config');

const supabase = createClient(config.supabaseUrl, config.supabaseServiceRoleKey, {
  auth: { persistSession: false, autoRefreshToken: false }
});
const client = new Client({ intents: [GatewayIntentBits.Guilds] });

const hasRole = (interaction, roleId) => Boolean(interaction.member?.roles?.cache?.has(roleId));
const isAdmin = interaction => hasRole(interaction, config.adminRoleId);
const isMember = interaction => isAdmin(interaction) || hasRole(interaction, config.memberRoleId);
const replyOptions = () => ({ ephemeral: config.ephemeral });
const cleanName = value => value.trim().replace(/\s+/g, ' ');

function validHttpsUrl(value) {
  try { return new URL(value).protocol === 'https:'; }
  catch { return false; }
}
function makeLoader(url) {
  const escaped = url.replace(/\\/g, '\\\\').replace(/"/g, '\\"');
  return `loadstring(game:HttpGet("${escaped}"))()`;
}
async function getScript(name) {
  const { data, error } = await supabase.from('scripts')
    .select('id,name,url,created_by,created_at').ilike('name', name).limit(1).maybeSingle();
  if (error) throw error;
  return data;
}
async function errorReply(interaction, message) {
  const payload = { content: `❌ ${message}`, ...replyOptions() };
  if (interaction.deferred || interaction.replied) return interaction.followUp(payload);
  return interaction.reply(payload);
}

client.once('ready', () => {
  console.log(`Logged in as ${client.user.tag}`);
  client.user.setActivity('Clipper Loadstring Hub');
});

client.on('interactionCreate', async interaction => {
  if (!interaction.isChatInputCommand()) return;
  try {
    const command = interaction.commandName;

    if (command === 'help') {
      const embed = new EmbedBuilder().setColor(0x9b6cff).setTitle('Clipper Loadstring Bot')
        .setDescription([
          '`/scripts` — lihat daftar script',
          '`/loadstring name:<nama>` — buat loader dari script tersimpan',
          '`/addscript name:<nama> url:<https-url>` — admin saja',
          '`/deletescript name:<nama>` — admin saja',
          '',
          'Member dan Admin dapat melihat serta generate. Admin dapat mengelola daftar.',
          'Gunakan hanya script milik sendiri atau yang kamu punya izin untuk distribusikan.'
        ].join('\n'));
      return interaction.reply({ embeds: [embed], ...replyOptions() });
    }

    if (command === 'scripts') {
      if (!isMember(interaction)) return errorReply(interaction, 'Kamu perlu role Member atau Admin.');
      await interaction.deferReply(replyOptions());
      const { data, error } = await supabase.from('scripts').select('name').order('name').limit(50);
      if (error) throw error;
      if (!data?.length) return interaction.editReply('Belum ada script yang tersimpan.');
      const description = data.map((item, index) => `\`${index + 1}.\` ${item.name}`).join('\n');
      return interaction.editReply({ embeds: [new EmbedBuilder().setColor(0x9b6cff).setTitle('Saved Scripts').setDescription(description)] });
    }

    if (command === 'loadstring') {
      if (!isMember(interaction)) return errorReply(interaction, 'Kamu perlu role Member atau Admin.');
      await interaction.deferReply(replyOptions());
      const name = cleanName(interaction.options.getString('name', true));
      const script = await getScript(name);
      if (!script) return interaction.editReply(`Script **${name}** tidak ditemukan. Gunakan \`/scripts\`.`);
      const embed = new EmbedBuilder().setColor(0x55d6a3).setTitle(`Loader: ${script.name}`)
        .setDescription('```lua\n' + makeLoader(script.url) + '\n```')
        .setFooter({ text: 'Clipper Loadstring Hub • Gunakan hanya dengan izin' });
      return interaction.editReply({ embeds: [embed] });
    }

    if (command === 'addscript') {
      if (!isAdmin(interaction)) return errorReply(interaction, 'Command ini khusus role Admin.');
      const name = cleanName(interaction.options.getString('name', true));
      const url = interaction.options.getString('url', true).trim();
      if (!validHttpsUrl(url)) return errorReply(interaction, 'URL harus valid dan menggunakan HTTPS.');
      await interaction.deferReply(replyOptions());
      const { data, error } = await supabase.from('scripts').insert({ name, url, created_by: interaction.user.id }).select('name').single();
      if (error) {
        if (error.code === '23505') return interaction.editReply('Nama script sudah dipakai. Gunakan nama lain.');
        throw error;
      }
      return interaction.editReply(`✅ Script **${data.name}** berhasil disimpan.`);
    }

    if (command === 'deletescript') {
      if (!isAdmin(interaction)) return errorReply(interaction, 'Command ini khusus role Admin.');
      const name = cleanName(interaction.options.getString('name', true));
      await interaction.deferReply(replyOptions());
      const { data, error } = await supabase.from('scripts').delete().ilike('name', name).select('name');
      if (error) throw error;
      if (!data?.length) return interaction.editReply(`Script **${name}** tidak ditemukan.`);
      return interaction.editReply(`🗑️ Script **${data[0].name}** berhasil dihapus.`);
    }
  } catch (error) {
    console.error('Interaction error:', error);
    await errorReply(interaction, 'Terjadi kesalahan. Periksa log hosting dan konfigurasi Supabase.');
  }
});

client.login(config.token);
